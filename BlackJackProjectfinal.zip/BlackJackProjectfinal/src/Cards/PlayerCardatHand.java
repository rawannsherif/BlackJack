package Cards;

public class PlayerCardatHand extends CardatHand{
 
    public PlayerCardatHand()
    {
        super();
    }
    
    public boolean add(Card card)
    {
        boolean cardAdded = false;
        
        if (!isBust() && !hasBlackjack())
        {
            cardAdded = super.add(card);
                        
            if (isBust())
            {
                for (Card eachCard : this)
                {
                    eachCard.getFace().switchAce(); 
                    
                    if (!isBust()) 
                    {
                        break; 
                    }
                }
            }
        }
        return (cardAdded) ? true : false;
    }
}
