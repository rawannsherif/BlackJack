package Cards;

public class DealerCardatHand extends CardatHand{
   
    public DealerCardatHand()
    {
        super();
    }
    
    public boolean add(Card card)
    {
        boolean cardAdded = false;
        if (!isBust() && !hasBlackjack())
        {            
            cardAdded = super.add(card);
        }
        return (cardAdded) ? true : false;
    }
}

