
package blackjackproject;
import javax.swing.*;
import java.awt.*;
import java.net.URL;
import Cards.*;

public class GameTable extends JPanel{

    private DealerCardatHand dealer;
    private PlayerCardatHand player;
    private boolean showalldealercards;
    
    private final int CARD_INCREASE = 20;
    private final int CARD_START = 100;
    private final int POS_DEALER = 50;
    private final int POS_PLAYER = 200;
    
    private final int CARD_IMAGE_WIDTH = 71;
    private final int CARD_IMAGE_HEIGHT = 96;
    
    private final int NAME_SPACE = 10;
    
    private Font totalhandfont;
    private Font playerNameFont;
    
    private String dealerName;
    private String playerName;
    
    private Image[] cardImages = new Image[CardPack.CARDS_IN_PACK + 1];
    
    public GameTable()
    {
        super();
        
        this.setBackground(Color.BLUE);
        this.setOpaque(false);
        
        totalhandfont = new Font("Serif", Font.PLAIN, 96);
        playerNameFont = new Font("Serif", Font.ITALIC, 20);
        
        showalldealercards = true;
        
        for (int i = 0; i < CardPack.CARDS_IN_PACK; i++)
        {
            String cardName = "C:\\Users\\Rawan\\Desktop\\java-blackjack-master\\java-blackjack-master\\src\\card_images\\" + (i+1) + ".png";
            
            URL urlImg = getClass().getResource(cardName);
            Image cardImage = Toolkit.getDefaultToolkit().getImage(cardName);
            cardImages[i] = cardImage;
        }
        
        String backCard = "C:\\Users\\Rawan\\Desktop\\java-blackjack-master\\java-blackjack-master\\src\\card_images\\red_back.png";
        
        URL backCardURL = getClass().getResource(backCard);
        Image backCardImage = Toolkit.getDefaultToolkit().getImage(backCard);
        
        cardImages[CardPack.CARDS_IN_PACK] = backCardImage;
        
        MediaTracker imageTracker = new MediaTracker(this);
        
        for (int i = 0; i < CardPack.CARDS_IN_PACK + 1; i++)
        {
            imageTracker.addImage(cardImages[i], i + 1); 
        }
        
        try
        {
            imageTracker.waitForAll();
        }
        catch (InterruptedException excep)
        {
            System.out.println(" loading card images failed");
        }
    }
    
    public void setNames(String dealerName, String playerName)
    {
        this.dealerName = dealerName;
        this.playerName = playerName;
    }
    
    public void update(DealerCardatHand dealer, PlayerCardatHand player, boolean showDealer)
    {        
        this.dealer = dealer;
        this.player = player;
        this.showalldealercards = showDealer;
    }
        
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        
        g.setColor(Color.WHITE);
        g.setFont(playerNameFont);
        
        g.drawString(dealerName, CARD_START, POS_DEALER - NAME_SPACE);
        g.drawString(playerName, CARD_START, POS_PLAYER - NAME_SPACE);
        
        g.setFont(totalhandfont);
        
        String cardName;
        
        int i = CARD_START;
    
        if (showalldealercards)
        {
            for (Card eachCard : dealer)
            {
                g.drawImage(cardImages[eachCard.getCode() - 1], i, POS_DEALER, this);

                i += CARD_INCREASE;
            }
        
            g.drawString(Integer.toString(dealer.getTotal()), i 
                + CARD_IMAGE_WIDTH + CARD_INCREASE, POS_DEALER 
                + CARD_IMAGE_HEIGHT);
        }
        else
        {
            for (Card everyCard : dealer)
            {
                g.drawImage(cardImages[CardPack.CARDS_IN_PACK], i, POS_DEALER, this);

                i += CARD_INCREASE;
            }
        
            try
            {
                Card topCard = dealer.lastElement();
            
                i -= CARD_INCREASE;
            
                g.drawImage(cardImages[topCard.getCode() - 1], i, POS_DEALER, this);
                
            }
            catch (Exception e)
            {
                System.out.println("No cards dealt yet.");
            }
            
            g.drawString("?", i + CARD_IMAGE_WIDTH + CARD_INCREASE, 
                POS_DEALER + CARD_IMAGE_HEIGHT);
        }
        
        i = CARD_START;

        for (Card aCard : player)
        {
            g.drawImage(cardImages[aCard.getCode() - 1], i, POS_PLAYER, this);

            i += CARD_INCREASE;
        }
    
        g.drawString(Integer.toString(player.getTotal()), i + CARD_IMAGE_WIDTH + CARD_INCREASE, POS_PLAYER + CARD_IMAGE_HEIGHT); 
    }
}
