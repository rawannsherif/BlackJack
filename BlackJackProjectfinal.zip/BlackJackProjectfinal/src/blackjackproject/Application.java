package blackjackproject;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Application extends JFrame  implements ActionListener, ComponentListener{

    private GamePanel gamePanel;
    private Color defaultTableColour = new Color(6, 120, 0);
    
    final int WIDTH = 600;
    final int HEIGHT = 500;

    public Application()
    {
        super("Blackjack");
        
        addComponentListener(this);
        
        Dimension windowSize = new Dimension(WIDTH, HEIGHT);
        setSize(windowSize);
        setLocationRelativeTo(null); 
        
        this.setBackground(defaultTableColour);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        JMenuBar menuBar = new JMenuBar();
        JMenu playerMenu = new JMenu("Player");
        JMenuItem updatePlayerDetails = new JMenuItem("Update Player Details");
        
        playerMenu.add(updatePlayerDetails);
        playerMenu.addSeparator();
        menuBar.add(playerMenu);
        
        JMenu actionMenu = new JMenu("Actions");
        JMenuItem dealAction = new JMenuItem("Deal");
        JMenuItem hitAction = new JMenuItem("Hit");
        JMenuItem doubleAction = new JMenuItem("Double");
        JMenuItem standAction = new JMenuItem("Stand");
        actionMenu.add(dealAction);
        actionMenu.add(hitAction);
        actionMenu.add(doubleAction);
        actionMenu.add(standAction);
        menuBar.add(actionMenu);
        
        JMenu betMenu = new JMenu("Bet");
        JMenuItem oneChip = new JMenuItem("$1");
        JMenuItem fiveChip = new JMenuItem("$5");
        JMenuItem tenChip = new JMenuItem("$10");
        JMenuItem twentyFiveChip = new JMenuItem("$25");
        JMenuItem hundredChip = new JMenuItem("$100");
        betMenu.add(oneChip);
        betMenu.add(fiveChip);
        betMenu.add(tenChip);
        betMenu.add(twentyFiveChip);
        betMenu.add(hundredChip);
        menuBar.add(betMenu);
        
        JMenu windowMenu = new JMenu("Window");
        JMenuItem windowTableColourMenu = new JMenuItem("Change Table Colour");
        windowMenu.add(windowTableColourMenu);
        menuBar.add(windowMenu);
        
        JMenu helpMenu = new JMenu("Help");
        JMenuItem helpBlackjackRulesMenu = new JMenuItem("Blackjack Rules");
        helpMenu.add(helpBlackjackRulesMenu);
        helpMenu.addSeparator();
        menuBar.add(helpMenu);
        
        setJMenuBar(menuBar);
        
	dealAction.addActionListener(this);
        hitAction.addActionListener(this);
        doubleAction.addActionListener(this);
        standAction.addActionListener(this);
	updatePlayerDetails.addActionListener(this);
	windowTableColourMenu.addActionListener(this);
	oneChip.addActionListener(this);
        fiveChip.addActionListener(this);
        tenChip.addActionListener(this);
        twentyFiveChip.addActionListener(this);
        hundredChip.addActionListener(this);
        		
        gamePanel = new GamePanel();
        gamePanel.setBackground(defaultTableColour);
	add(gamePanel);
        setVisible(true);
    }

	public void actionPerformed(ActionEvent ex)
    {
        String job = ex.getActionCommand();
        
        if (job.equals("$1"))
        {
            gamePanel.increaseBet(1);
        }
        else if (job.equals("$5"))
        {
            gamePanel.increaseBet(5);
        }
        else if (job.equals("$10"))
        {
            gamePanel.increaseBet(10);
        }
        else if (job.equals("$25"))
        {
            gamePanel.increaseBet(25);
        }
        else if (job.equals("$100"))
        {
            gamePanel.increaseBet(100);
        }
        else if (job.equals("Deal"))
        {
            gamePanel.newGame();
        }
        else if (job.equals("Hit"))
        {
            gamePanel.hit();
        }
        else if (job.equals("Double"))
        {
            gamePanel.playDouble();
        }
        else if (job.equals("Stand"))
        {
            gamePanel.stand();
        }
        else if (job.equals("Update Player Details"))
        {
            gamePanel.updatePlayer();
        }
	else if (job.equals("Change Table Colour"))
		{
		    Color tableColour = JColorChooser.showDialog(this, "Select Table Colour", defaultTableColour);
		    this.setBackground(tableColour);
		    gamePanel.setBackground(tableColour);
		    gamePanel.repaint();
		    this.repaint();
		}
		else if (job.equals("About Blackjack"))
		{
		    String aboutText = "<html><p align=\"center\" style=\"padding-bottom: 10px;\">Written by David Winter &copy; 2006<br>Version 1.0</p><p align=\"center\" style=\"padding-bottom: 10px;\"><small>Become such an expert while developing this, <br>I won $1000 online in a game of Blackjack!</small></p><p align=\"center\">email: djw@davidwinter.me.uk<br>web: davidwinter.me.uk</p></html>";
		    JOptionPane.showMessageDialog(this, aboutText, "About Blackjack", JOptionPane.PLAIN_MESSAGE);
		}
		
		gamePanel.updateValues();
	}
	
	public void componentResized(ComponentEvent e)
	{
	    int currentWidth = getWidth();
	    int currentHeight = getHeight();
	    
	    boolean resize = false;
	    
	    if (currentWidth < WIDTH)
	    {
	        resize = true;
	        currentWidth = WIDTH;
	    }
	    
	    if (currentHeight < HEIGHT)
	    {
	        resize = true;
	        currentHeight = HEIGHT;
	    }
	    
	    if (resize)
	    {
	        setSize(currentWidth, currentHeight);
	    }
	}
	
	public void componentMoved(ComponentEvent e) { }
	public void componentShown(ComponentEvent e) { }
	public void componentHidden(ComponentEvent e) { }
}


