
package blackjackproject;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.*;
import Players.*;
import Cards.*;

public class GamePanel extends JPanel implements ActionListener{

    private Dealer dealer;
    private Player player;
    private GameTable table;
    
    private JButton newGameButton = new JButton("Deal");
    private JButton hitButton = new JButton("Hit");
    private JButton doubleButton = new JButton("Double");
    private JButton standButton = new JButton("Stand");
    private JButton oneChip = new JButton("1");
    private JButton fiveChip = new JButton("5");
    private JButton tenChip = new JButton("10");
    private JButton twentyfiveChip = new JButton("25");
    private JButton hundredChip = new JButton("100");
    private JButton clearBet =  new JButton("Clear");
    
    private JLabel currentBet = new JLabel("Please set your bet...");
    private JLabel playerWallet = new JLabel("$999.99");
    private JLabel cardsLeft = new JLabel("Cards left...");
    private JLabel dealerSays = new JLabel("Dealer says...");
    
    public GamePanel()
    {
        this.setLayout(new BorderLayout());
        
        table = new GameTable();
        add(table, BorderLayout.CENTER);
        
        JPanel betPanel = new JPanel();
        betPanel.add(currentBet);
        betPanel.add(clearBet);
        betPanel.add(oneChip);
        betPanel.add(fiveChip);
        betPanel.add(tenChip);
        betPanel.add(twentyfiveChip);
        betPanel.add(hundredChip);
        betPanel.add(playerWallet);
        
        JPanel dealerPanel = new JPanel();
        dealerPanel.add(dealerSays);
        
        JPanel optionsPanel = new JPanel();
        optionsPanel.add(newGameButton);
        optionsPanel.add(hitButton);
        optionsPanel.add(doubleButton);
        optionsPanel.add(standButton);
        optionsPanel.add(cardsLeft);
        
        JPanel bottomItems = new JPanel();
        bottomItems.setLayout(new GridLayout(0,1));
        bottomItems.add(dealerPanel);
        bottomItems.add(betPanel);
        bottomItems.add(optionsPanel);
        add(bottomItems, BorderLayout.SOUTH);
        
        betPanel.setOpaque(false);
        dealerPanel.setOpaque(false);
        optionsPanel.setOpaque(false);
        bottomItems.setOpaque(false);
        
        newGameButton.addActionListener(this);
        hitButton.addActionListener(this);
        doubleButton.addActionListener(this);
	standButton.addActionListener(this);
	clearBet.addActionListener(this);
        oneChip.addActionListener(this);
	fiveChip.addActionListener(this);
        tenChip.addActionListener(this);
	twentyfiveChip.addActionListener(this);
        hundredChip.addActionListener(this);

	newGameButton.setToolTipText("Deal a new game.");
	hitButton.setToolTipText("Request another card.");
	doubleButton.setToolTipText("Double your bet, and receive another card.");
	standButton.setToolTipText("Stand with your card-hand.");
        clearBet.setToolTipText("Clear your current bet.");
        oneChip.setToolTipText("Add a $1 chip to your current bet.");
        fiveChip.setToolTipText("Add a $5 chip to your current bet.");
        tenChip.setToolTipText("Add a $10 chip to your current bet.");
        twentyfiveChip.setToolTipText("Add a $25 chip to your current bet.");
        hundredChip.setToolTipText("Add a $100 chip to your current bet.");
		
	dealer = new Dealer();
        player = new Player("Rawan", 19, "Female");
        player.setWallet(100.00);
		
        updateValues();
    }
    
    public void actionPerformed(ActionEvent evn)
    {
        String job = evn.getActionCommand();
        
        if (job.equals("Deal"))
        {
            newGame();
        }
        else if (job.equals("Hit"))
        {
            hit();
        }
        else if (job.equals("Double"))
        {
            playDouble();
        }
        else if (job.equals("Stand"))
        {
            stand();
        }
        else if (job.equals("1") || job.equals("5") || job.equals("10") || job.equals("25") || job.equals("100"))
        {
            increaseBet(Integer.parseInt(job));
        }
        else if (job.equals("Clear"))
        {
            System.out.println("clear bet");
            clearBet();
        }
        
        updateValues();
    }
    
    public void newGame()
    {
        dealer.deal(player);
    }
    
    public void hit()
    {
        dealer.hit(player);
    }
    
    public void playDouble()
    {
        dealer.playDouble(player);
    }
    
    public void stand()
    {
        dealer.stand(player);
    }
    
    public void increaseBet(int amount)
    {
        dealer.acceptBetFrom(player, amount + player.getBet());
    }
    
    public void clearBet()
    {
        player.clearBet();
    }
    
    public void updateValues()
    {
        dealerSays.setText("<html><p align=\"center\"><font face=\"Serif\" color=\"white\" style=\"font-size: 20pt\">" + dealer.says() + "</font></p></html>");
        
        if (dealer.isGameOver())
        {
            if (player.betPlaced() && !player.isBankrupt())
            {
                newGameButton.setEnabled(true);
            }
            else
            {
                newGameButton.setEnabled(false);
            }
            hitButton.setEnabled(false);
            doubleButton.setEnabled(false);
            standButton.setEnabled(false);
            
            if (player.betPlaced())
            {
                clearBet.setEnabled(true);
            }
            else
            {
                clearBet.setEnabled(false);
            }
            
            if (player.getWallet() >= 1.0)
            {
                oneChip.setEnabled(true);
            }
            else
            {
                oneChip.setEnabled(false);
            }
            
            if (player.getWallet() >= 5)
            {
                fiveChip.setEnabled(true);
            }
            else
            {
                fiveChip.setEnabled(false);
            }
            
            if (player.getWallet() >= 10)
            {
                tenChip.setEnabled(true);
            }
            else
            {
                tenChip.setEnabled(false);
            }
            
            if (player.getWallet() >= 25)
            {
                twentyfiveChip.setEnabled(true);
            }
            else
            {
                twentyfiveChip.setEnabled(false);
            }
            
            if (player.getWallet() >= 100)
            {
                hundredChip.setEnabled(true);
            }
            else
            {
                hundredChip.setEnabled(false);
            }
        }
        else
        {
            newGameButton.setEnabled(false);
            hitButton.setEnabled(true);
            if (dealer.canPlayerDouble(player))
            {
                doubleButton.setEnabled(true);
            }
            else
            {
                doubleButton.setEnabled(false);
            }
            
            standButton.setEnabled(true);
            
            clearBet.setEnabled(false);
            oneChip.setEnabled(false);
            fiveChip.setEnabled(false);
            tenChip.setEnabled(false);
            twentyfiveChip.setEnabled(false);
            hundredChip.setEnabled(false);
        }
        
        table.update(dealer.getHand(), player.getHand(), (dealer.areCardsFaceUp()) ? true : false);
	table.setNames(dealer.getName(), player.getName());
        table.repaint();
        
        cardsLeft.setText("Deck: " + dealer.cardsLeftInPack() + "/" + (dealer.CARD_PACKS * Cards.CardPack.CARDS_IN_PACK));
        
        if (player.isBankrupt())
        {
            moreFunds();
        }
        
        currentBet.setText(Double.toString(player.getBet()));
        playerWallet.setText(Double.toString(player.getWallet()));
    }
    
    private void moreFunds()
    {
        int response = JOptionPane.showConfirmDialog(null, "One Hundered Dollars worth of aid", "Out of funds", JOptionPane.YES_NO_OPTION);
        
        if (response == JOptionPane.YES_OPTION)
        {
            player.setWallet(100.00);
            updateValues();
        }
    }
	
	public void updatePlayer()
	{
	PlayerDialog playerDetails = new PlayerDialog(null, "Player Details", true, player);
        playerDetails.setVisible(true);
        
        player = playerDetails.getPlayer();
	}
}

